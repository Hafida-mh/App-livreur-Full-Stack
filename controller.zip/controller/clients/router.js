const express = require("express");
const routerControllerClient = express.Router();
const controllerClient = require('../clients/controller');



routerControllerClient.post('/signup', controllerClient.signup );
routerControllerClient.post('/connexion', controllerClient.checkConnexionClient);
routerControllerClient.put('/upDateNumber', controllerClient.upDateNumber);

module.exports = routerControllerClient;