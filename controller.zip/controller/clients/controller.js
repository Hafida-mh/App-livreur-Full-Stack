const mysql = require('mysql');
const jwt = require("jsonwebtoken");
const bcrypt = require('bcryptjs');
require("dotenv").config();



//signup



const signup = async (req, res) => {


  // connect BDD
  const connection = mysql.createConnection({
    host: "localhost",
          user: "c1493488c_livuser",
          password: "livreurUser",
          database: "c1493488c_liv",
          port : 3306
  });

  connection.connect(function (err) {
    if (err) throw err;
    console.log("Database livreur Connected!");
  });

  const id = req.body.id;
  const Nom = req.body.Nom;
  const Prenom = req.body.Prenom;
  const Telephone = req.body.Telephone;
  const Email = req.body.Email;
  const Statut = req.body.Statut;
  const Password = req.body.Password

console.log(Password)
  const salt = await bcrypt.genSalt(10);
  
  const hashedPassword = await bcrypt.hash(Password, salt);
  const hashedPasswordstring = JSON.stringify(hashedPassword);

  let verify = `SELECT COUNT(*) AS cnt FROM signupClient_TB WHERE email = ?`;

  connection.query(verify, [Email], (err, results, fields) => {
    if (err) {
      return console.error(err.message);
    }

    else if (results[0].cnt > 0) {
      res.send({
        messageSuccess: "",
        messageError: "Adresse mail existe déja"
      })

    }


    else {

      const token = jwt.sign({ Email: req.body.Email, Password: req.body.Password }, process.env.ACCESS_TOKEN_SECRET);

      //  const hashedPasswordstring= JSON.stringify(hashedPassword);
      console.log(hashedPassword)
      //const Unik = 'NULL'

      //console.log(hashedPasswordstring)
      let stmt = "INSERT INTO `signupClient_TB`(id, Nom, Prenom, Telephone, Email, Statut, Password, Token) VALUES (?,?,?,?,?,?,?,?)";
      let values = [id, Nom, Prenom, Telephone, Email, Statut, hashedPasswordstring, token];


      // execute the insert statment
      connection.query(stmt, values, (err, results, fields) => {
        if (err) {
          return console.error(err.message);
        }
        // get inserted id
console.log(results)

    
        res.status(200).send({
          messageError: "",
          messageSuccess: "Inscription réussite",
          token : token
        });

        console.log('Todo Id:' + results.insertId);
      });


      connection.end();

    }



  });
}






/*
const verifyPassword = async (pwreq,pwBDD) => {
  const validpass =  await bcrypt.compare(pwreq, pwBDD);
  return validpass
}
async function  verifyPassword(pwreq,pwBDD){
  const validpass =  await bcrypt.compare(pwreq, pwBDD);
  return validpass
}
*/


// salt : $2a$10$I.D0Svy.Xq0mv3/c6m.2/.







// CONNEXION 

 const checkConnexionClient = async (req, res) => {

  const Email = req.body.Email;
  const Password =  req.body.Password;
  const salt = await bcrypt.genSalt(10);

//console.log(Password)
  
  // const validpass = await bcrypt.compare(req.body.password, user.password);

  const connection = mysql.createConnection({
    host: "localhost",
    user: "c1493488c_livuser",
    password: "livreurUser",
    database: "c1493488c_liv",
    port : 3306
  });


  connection.connect(function (err) {
    if (err) throw err;
  });


  let verify = `SELECT COUNT(*) AS cnt FROM signupClient_TB WHERE email = ?`;

  connection.query(verify, [Email, Password],  (err, results, fields) =>{
    if (err) {
      return console.error(err.message);
    }

    else if (results[0].cnt > 0){

   connection.query(`SELECT Password, Email, Token from signupClient_TB WHERE  signupClient_TB.Email="${Email}"`,     (err, results, fields) =>{
  
      // var string=JSON.stringify(results[0].Password);
     //  var json =  JSON.parse(string);
     // console.log(results[0].Password)
     // console.log(req.body.Password)

    // const validpass =   bcrypt.compareSync(results[0].Password, req.body.Password );
  
    const verified = jwt.verify(results[0].Token, process.env.ACCESS_TOKEN_SECRET)


       //console.log(verified.Password)
     //   const validpass  =   verifyPassword(req.body.password, json)
       
        if(verified.Email === req.body.Email && verified.Password === req.body.Password){
              res.send({
                messageError: "",
                messageSuccess: "Connexion réussite",
                data: verified.Email

               
              })
            }

        else{
        
          res.send({
            messageError: "Mot de passe ou adresse mail incorrecte",
            messageSuccess: ""
          });

        }
      })}


    else {
      res.send({
        messageError: "Veuillez vos inscrirre",
        messageSuccess: ""
      })
    }

  })


/*

 // DETERMINER LE MOT DE PASSE CORRESPONANT à L'EMAIL
  connection.query(`SELECT Password from signupClient_TB WHERE  signupClient_TB.Email="${Email}"`, (err, results, fields) => {

           if (err) {
            return console.error(err.message);
           }
                                                                                                       
           else {
            const validpass = bcrypt.compare(req.body.password, results[0].Password);

            if (!validpass) {
              res.send({
                messageError: "Mot de passe incorrect",
                messageSuccess: ""
              })
            }


            else {
              const token = jwt.sign({ Email: results[0].Email }, process.env.ACCESS_TOKEN_SECRET);

              const verified = jwt.verify(token, process.env.ACCESS_TOKEN_SECRET);

              res.send({
                messageError: "",
                messageSuccess: "Connexion réussite",
                pass: verified
              });

            }

            // console.log(results[0].Password)
           }

        }
  connection.query(verify, [Email, Password], (err, results, fields) => {
    if (err) {
      return console.error(err.message);
    }

    else {



      if (results[0].cnt > 0) {
        connection.query(`SELECT Password, Email from signupClient_TB WHERE signupClient_TB.Password ="${Password}" AND signupClient_TB.Email="${Email}"`, (err, results, fields) => {

           if (err) {
            return console.error(err.message);
           }
                                                                                                       
           else {
            const validpass = bcrypt.compare(req.body.password, results[0].Password);

            if (!validpass) {
              res.send({
                messageError: "Mot de passe incorrect",
                messageSuccess: ""
              })
            }


            else {
              const token = jwt.sign({ Email: results[0].Email }, process.env.ACCESS_TOKEN_SECRET);

              const verified = jwt.verify(token, process.env.ACCESS_TOKEN_SECRET);

              res.send({
                messageError: "",
                messageSuccess: "Connexion réussite",
                pass: verified
              });

            }

            // console.log(results[0].Password)
           }

        })
      }
    }
  })*/
}





// *****************************************************   UPDATE NUMBER **************************************

const upDateNumber = (req, res) => {
  const id = req.body.id


  const connection = mysql.createConnection({
    host: "localhost",
          user: "c1493488c_livuser",
          password: "livreurUser",
          database: "c1493488c_liv",
          port : 3306

  });


  connection.connect(function (err) {
    if (err) throw err;
    console.log("Database livreur Connected!");
  });


  //SELECT * FROM signup_TB WHERE signup_TB.id = "${id}"

  connection.query(`UPDATE signupClient_TB SET signupClient_TB.Statut= 'playyard' WHERE signupClient_TB.id = '7129f714-5e34-45d5-a395-d202361d363f'`, function (err, result) {
    if (err) throw err;
    console.log(result);
  });

  const crypto = require('crypto');
  const key = crypto.randomBytes(32).toString('hex')
  console.log(key)
}

module.exports = {
  signup,
  checkConnexionClient,
  upDateNumber
}