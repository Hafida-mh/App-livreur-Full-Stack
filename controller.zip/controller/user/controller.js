const mysql = require('mysql');


// **********  Create connexions to dataBase  ***********




/*  SIGNUP */
const postUser = (req, res) => {
  const connection = mysql.createConnection({
    host: "localhost",
    user: "c1493488c_livuser",
    password: "livreurUser",
    database: "c1493488c_liv",
    port : 3306
  });

  connection.connect(function (err) {
    if (err) throw err;
    console.log("Database livreur Connected!");
  });

  const id = req.body.id;
  const Nom = req.body.Nom;
  const Prenom = req.body.Prenom;
  const Telephone = req.body.Telephone;
  const Email = req.body.Email;
  const Wilaya = req.body.Wilaya;
  const Commune = req.body.Commune;
  const Adresse = req.body.Adresse;
  const Vehicule = req.body.Vehicule;
  const Matricule = req.body.Matricule;
  const Permis = req.body.Permis;
  const Cartegrise = req.body.Cartegrise;
  const Password = req.body.Password;

  /* FIND OUT IF THE USER ALREADY EXISTS (later)*/


  /* POST DATA*/
  let verify = `SELECT COUNT(*) AS cnt FROM signup_TB WHERE email = ?`;

  connection.query(verify, [Email], (err, results, fields) => {
    if (err) {
      return console.error(err.message);
    }

    else if (results[0].cnt > 0) {
      res.send({
        messageSuccess: "",
        messageError: "Adresse mail existe déja"
      })

    }


    else {

      let stmt = `INSERT INTO signup_TB (Nom,Prenom,id,Telephone,Email,Wilaya,Commune,Adresse,Vehicule,Matricule,Permis,Cartegrise,Password ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)`;
      let values = [Nom, Prenom, id, Telephone, Email, Wilaya, Commune, Adresse, Vehicule, Matricule, Permis, Cartegrise, Password];


      // execute the insert statment
      connection.query(stmt, values, (err, results, fields) => {
        if (err) {
          return console.error(err.message);
        }
        // get inserted id
        res.send({
          messageError: "",
          messageSuccess: "Inscription réussite"
        });

        console.log('Todo Id:' + results.insertId);
      });





      connection.end();

    }



  });


}



/* GET LIST USERS */


const getUser = (req, res) => {

  const connection = mysql.createConnection({
    host: "localhost",
    user: "c1493488c_livuser",
    password: "livreurUser",
    database: "c1493488c_liv",
    port : 3306

  });


  connection.connect(function (err) {
    if (err) throw err;

  });


  const qr = 'SELECT * FROM `signup_TB`'
  connection.query('SELECT * FROM `signup_TB`', (err, results, fields) => {


    var string = JSON.stringify(results);
    var json = JSON.parse(string);


    //console.log(json)
    res.send({
      data: json
    })
    if (err) {
      return console.error(err.message);
    }
  });
}






// Check connexion .....

const checkConnexion = (req, res) => {

  const Email = req.body.Email;
  const Password = req.body.Password;


  const connection = mysql.createConnection({
    host: "localhost",
    user: "c1493488c_livuser",
    password: "livreurUser",
    database: "c1493488c_liv",
    port : 3306

  });


  connection.connect(function (err) {
    if (err) throw err;
  });


  let verify = `SELECT COUNT(*) AS cnt FROM signup_TB WHERE email = ? AND password = ?`;

  connection.query(verify, [Email ,Password], (err, results, fields) => {
    if (err) {
      return console.error(err.message);
    }
    else {

      if (results[0].cnt > 0) {
        res.send({
          messageError  : "",
          messageSuccess: "Connexion réussite"
        })
      }
  
      else {
        res.send({
          messageError: "Adresse mail ou mot de passe incorrecte",
          messageSuccess : ""
        })
      }

    }
   
  })
}






// SEND INFORMATION OF LIVREUR


const getLivreurInfo = (req,res) => {
  const id = req.body.id;

  const connection = mysql.createConnection({
    host: "localhost",
    user: "c1493488c_livuser",
    password: "livreurUser",
    database: "c1493488c_liv",
    port : 3306

  });


  connection.connect(function (err) {
    if (err) throw err;
  });

  const query = `SELECT * FROM signup_TB  WHERE id = ${id}`
  connection.query(query,id, (err, results, fields) => {
    if (err) {
      return console.error(err.message);
    }

    else{
      var string = JSON.stringify(results);
      var json = JSON.parse(string);
  
  
      //console.log(json)
      res.send({
        data: results
      })
    }
    console.log("hii")
  
  });


  
}

module.exports = {
  postUser,
  getUser,
  checkConnexion,
  getLivreurInfo
}